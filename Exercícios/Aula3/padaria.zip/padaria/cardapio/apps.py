from django.apps import AppConfig


class CardapioConfig(AppConfig):
    name = 'cardapio'
